import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Enhanced Calculator with History',
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blue,
      ),
      home: Calculator(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Calculator extends StatefulWidget {
  @override
  _CalculatorState createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  String output = "0";
  String currentOperation = ""; // Tracks the current operation
  double num1 = 0;
  double num2 = 0;
  String operand = "";
  bool isDecimal = false;
  List<String> history = []; // Stores calculation history

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  // Load history from SharedPreferences
  _loadHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      history = prefs.getStringList('history') ?? [];
    });
  }

  // Save history to SharedPreferences
  _saveHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('history', history);
  }

  void buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == "C") {
        output = "0";
        num1 = 0;
        num2 = 0;
        operand = "";
        isDecimal = false;
        currentOperation = ""; // Clear current operation display
      } else if (buttonText == "⌫") {
        output = output.length > 1 ? output.substring(0, output.length - 1) : "0";
      } else if (buttonText == "+" || buttonText == "-" || buttonText == "×" || buttonText == "÷") {
        num1 = double.tryParse(output) ?? 0;
        operand = buttonText;
        output = "0";
        isDecimal = false;
        currentOperation = "$num1 $operand "; // Show the current operation being built
      } else if (buttonText == ".") {
        if (!isDecimal) {
          output += ".";
          isDecimal = true;
        }
      } else if (buttonText == "=") {
        num2 = double.tryParse(output) ?? 0;
        String result = "";
        switch (operand) {
          case "+":
            result = (num1 + num2).toString();
            break;
          case "-":
            result = (num1 - num2).toString();
            break;
          case "×":
            result = (num1 * num2).toString();
            break;
          case "÷":
            result = num2 != 0 ? (num1 / num2).toString() : "Error";
            break;
        }
        if (result.isNotEmpty) {
          history.add("$num1 $operand $num2 = $result");
          _saveHistory(); // Save history after each calculation
          output = double.tryParse(result)?.toStringAsFixed(result.contains('.') ? 2 : 0) ?? result;
          currentOperation = "$num1 $operand $num2 = $result"; // Show the result of the operation
        }
        num1 = 0;
        num2 = 0;
        operand = "";
        isDecimal = false;
      } else {
        output = (output == "0") ? buttonText : output + buttonText;
      }
    });
  }

  Widget buildButton(String text, Color color) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: ElevatedButton(
          onPressed: () => buttonPressed(text),
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(vertical: 18.0),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            backgroundColor: color,
          ),
          child: Text(
            text,
            style: TextStyle(fontSize: 22.0, color: Colors.white),
          ),
        ),
      ),
    );
  }

  void navigateToHistory(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HistoryScreen(history: history, clearHistory: clearHistory),
      ),
    );
  }

  void clearHistory() {
    setState(() {
      history.clear();
    });
    _saveHistory(); // Clear history in SharedPreferences as well
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Enhanced Calculator'),
        backgroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Icon(Icons.history),
            onPressed: () => navigateToHistory(context),
          )
        ],
      ),
      body: Column(
        children: <Widget>[
          // Display current operation
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
            child: Text(
              currentOperation,
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.w300, color: Colors.white),
            ),
          ),
          // Display result
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(vertical: 24.0, horizontal: 12.0),
            child: Text(
              output,
              style: TextStyle(fontSize: 48.0, fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Divider(),
          ),
          Column(
            children: [
              Row(
                children: <Widget>[
                  buildButton("C", Colors.red),
                  buildButton("⌫", Colors.orange),
                  buildButton("÷", Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("7", Colors.grey),
                  buildButton("8", Colors.grey),
                  buildButton("9", Colors.grey),
                  buildButton("×", Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("4", Colors.grey),
                  buildButton("5", Colors.grey),
                  buildButton("6", Colors.grey),
                  buildButton("-", Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("1", Colors.grey),
                  buildButton("2", Colors.grey),
                  buildButton("3", Colors.grey),
                  buildButton("+", Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("0", Colors.grey),
                  buildButton(".", Colors.grey),
                  buildButton("=", Colors.green),
                ],
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
              'Developed by Muhammad Adnan',
              style: TextStyle(fontSize: 16.0, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}

class HistoryScreen extends StatelessWidget {
  final List<String> history;
  final VoidCallback clearHistory;

  HistoryScreen({required this.history, required this.clearHistory});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('History'),
        backgroundColor: Colors.black,
      ),
      body: Column(
        children: [
          Expanded(
            child: history.isEmpty
                ? Center(
              child: Text(
                'No history available',
                style: TextStyle(fontSize: 18.0, color: Colors.grey),
              ),
            )
                : ListView.builder(
              itemCount: history.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(
                    history[index],
                    style: TextStyle(fontSize: 18.0),
                  ),
                );
              },
            ),
          ),
          ElevatedButton(
            onPressed: () {
              clearHistory();
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text(
              'Clear History',
              style: TextStyle(fontSize: 18.0),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            child: Text(
              'Back to Calculator',
              style: TextStyle(fontSize: 18.0),
            ),
          ),
        ],
      ),
    );
  }
}
